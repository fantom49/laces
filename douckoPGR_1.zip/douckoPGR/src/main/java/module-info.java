module com.example.douckopgr {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.douckopgr to javafx.fxml;
    exports com.example.douckopgr;
}