module com.example.timertimer {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.media;


    opens com.example.timertimer to javafx.fxml;
    exports com.example.timertimer;
}