module com.example.testphasesevent {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.testphasesevent to javafx.fxml;
    exports com.example.testphasesevent;
}