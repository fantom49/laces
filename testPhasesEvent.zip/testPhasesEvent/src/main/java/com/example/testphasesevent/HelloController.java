package com.example.testphasesevent;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;

import java.net.URL;
import java.util.ResourceBundle;

public class HelloController implements Initializable {
    @FXML
    private Circle circle;

    @FXML
    private VBox vb;

    @FXML
    private Text pos;

    @FXML
    private GridPane root;
    EventHandler<MouseEvent> filter = e -> System.out.println("Fáze zachycení vyvolána"+e.getSource().getClass().getSimpleName());
    EventHandler<MouseEvent> handler = new EventHandler<MouseEvent>() {
        @Override
        public void handle(MouseEvent event) {
            System.out.print(" Zdroj:"+event.getSource().getClass().getSimpleName());
            System.out.print(" Cíl:"+event.getTarget().getClass().getSimpleName());
            System.out.println(" Typ:"+event.getEventType());
        }
    };

    EventHandler<MouseEvent> position = event -> {
        double x = event.getSceneX();
        double y = event.getSceneY();
        pos.setText("x: " + x + "; y: " + y);
    };

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        System.out.println("Program je spuštený");
//        circle.addEventFilter(MouseEvent.MOUSE_CLICKED,filter);
//        vb.addEventFilter(MouseEvent.MOUSE_CLICKED,filter);
//        circle.addEventHandler(MouseEvent.ANY,handler);
//        circle.setOnMouseClicked(handler);
        root.addEventFilter(MouseEvent.ANY,position);
    }

}